<?php
$page_title = "Admin Dashboard";
$content = "pages/admdashboard_content.php";
include('layout.php');
?>

