<?php
$page_title = "Admin Dashboard";
$content = "pages/manage_user_content.php";
include('layout.php');
?>

