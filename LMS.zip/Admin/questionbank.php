<?php
$page_title = "Admin Dashboard";
$content = "pages/questionbank_content.php";
include('layout.php');
?>

