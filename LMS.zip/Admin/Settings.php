<?php
$page_title = "Admin Dashboard";
$content = "pages/settings_content.php";
include('layout.php');
?>

