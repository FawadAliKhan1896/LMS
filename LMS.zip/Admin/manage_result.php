<?php
$page_title = "Admin Dashboard";
$content = "pages/manage_result_content.php";
include('layout.php');
?>

