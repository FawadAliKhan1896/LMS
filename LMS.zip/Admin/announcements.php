<?php
$page_title = "Admin Dashboard";
$content = "pages/announcement_content.php";
include('layout.php');
?>

