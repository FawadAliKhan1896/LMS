 <!-- Footer -->
  <footer class="main-footer text-center">
     <strong>© <span id="currentYear"></span> IT</strong> All rights reserved.
  </footer>