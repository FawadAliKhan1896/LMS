<?php
$page_title = "Admin Dashboard";
$content = "pages/manage_course_content.php";
include('layout.php');
?>

