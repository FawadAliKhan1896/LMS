<?php
$page_title = "Instructor Dashboard";
$content = "pages/profile_content.php";
include('layout.php');
?>

