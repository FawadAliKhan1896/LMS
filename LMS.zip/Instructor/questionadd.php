<?php
$page_title = "Instructor Dashboard";
$content = "pages/questionadd_content.php";
include('layout.php');
?>

  