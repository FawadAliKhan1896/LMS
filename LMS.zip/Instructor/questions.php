<?php
$page_title = "Instructor Dashboard";
$content = "pages/questions_content.php";
include('layout.php');
?>

