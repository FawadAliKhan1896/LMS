<?php
$page_title = "Instructor Dashboard";
$content = "pages/insdashboard_content.php";
include('layout.php');
?>

