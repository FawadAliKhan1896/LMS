<?php
$page_title = "Instructor Dashboard";
$content = "pages/results_content.php";
include('layout.php');
?>

  