<?php
$page_title = "Student Dashboard";
$content = "pages/stddashboard_content.php";
include('layout.php');
?>

