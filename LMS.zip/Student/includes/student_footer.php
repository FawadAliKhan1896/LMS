<footer class="main-footer text-center">
    <strong>© 2025 All rights reserved.</strong>
  </footer>