<?php
$page_title = "Student Dashboard";
$content = "pages/myexams_content.php";
include('layout.php');
?>

