<?php
$page_title = "Student Dashboard";
$content = "pages/material_content.php";
include('layout.php');
?>

