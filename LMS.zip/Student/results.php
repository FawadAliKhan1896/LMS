<?php
$page_title = "Student Dashboard";
$content = "pages/results_content.php";
include('layout.php');
?>

